# Qlik Sense Fast Type Change Bar Chart
This is a chart extension based on <a href="https://ecomfe.github.io/echarts-doc/public/en/index.html" target="_blank">eCharts</a>.
This bar chart is capable of fast type change to table and Line chart.

![Bar Chart Demo](https://raw.githubusercontent.com/oliveira89/QlikSense_FastTypeChangeBar/master/images/demo.gif)

More functionality will be added in the future.
